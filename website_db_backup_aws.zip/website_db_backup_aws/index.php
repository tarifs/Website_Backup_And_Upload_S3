<?php
// Config file
require('./config.php');
// Required files
require 'file_backup.php';
require 'db_backup.php';
require 'vendor/autoload.php';

$date = date('Y-m-d');

// ................File backup.................
$fileBackup = new FileBackup();
$fileBackup->backupFile($project_dir, $project_destination);
$fileKey = $date.'/project_backup.zip';
//sendToAws($fileKey, $fileBackup->filename);

// ................DB backup...................
// Creating New Instance for the class DatabaseBackup
$dbBackup	=	new DatabaseBackup($db_host, $db_user, $db_pass, $db_name);
$dbBackup->backupDatabase($db_dir);
$dbKey = $date.'/db_backup.sql';
//sendToAws($dbKey, $dbBackup->backupDirectory.'/'.$dbBackup->filename . '.sql');

//function sendToAws($key, $source){
//    global $aws_region, $aws_key, $aws_secret, $aws_bucket;
//
//    $s3 = new Aws\S3\S3Client([
//        'region'  => $aws_region, // aws region
//        'version' => 'latest',
//        'credentials' => [
//            'key'    => $aws_key, // aws key
//            'secret' => $aws_secret, // aws secret
//        ]
//    ]);
//
//    $result = $s3->putObject([
//        'Bucket' => $aws_bucket, // aws bucket
//        'Key'    => $key,
//        'Body'   => 'this is the body!',
//        'SourceFile' => $source
//    ]);
//}

// Remove file form server
DatabaseBackup::deleteDir($project_destination);
// Remove db from server
DatabaseBackup::deleteDir($db_dir);
exit;