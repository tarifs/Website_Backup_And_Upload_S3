<?php
// Config file
require('./config.php');
/* Error Reporting */
error_reporting(E_ERROR | E_PARSE);

class DatabaseBackup{
    public $tables = '*';
    public $hostname		=	'';
    public $username		=	'';
    public $password		=	'';
    public $database		=	'';
    public $characterSet		=	'utf8';
    public $backupDirectory	=	'./dbBackup';
    public $filename = '';

    // Mysqli Connection
    public $link			=	'';

    function __construct($hostname, $username, $password, $database){
        // Initialization of DB variables
        $this->hostname		=	$hostname;
        $this->username		=	$username;
        $this->password		=	$password;
        $this->database		=	$database;
        // Initialization DB
        $this->initializeDB();

    }

    public function initializeDB(){
        $this->link	=	mysqli_connect($this->hostname, $this->username, $this->password, $this->database);
        if(mysqli_connect_error()){
            die('Connection Error - '.mysqli_connect_errno().' : '.mysqli_connect_error());
        }
        if(!mysqli_character_set_name($this->link)){
            mysqli_set_charset($this->link,$this->characterSet);
        }
    }

    public function backupDatabase($tables = '*',$backupDirectory = ''){

        // Remove previous file
        $backupDirectoryR = ($backupDirectory == '') ? $this->backupDirectory : $backupDirectory;

        self::deleteDir($backupDirectoryR);

        /* If all the tables needed */
        if($tables == '*'){
            $tables =	array();
            /* Fetch all the tables of the current database */
            $result	=	mysqli_query($this->link,"SHOW TABLES");
            /* Loop through all the rows and assign to $tables array */
            while($row = mysqli_fetch_row($result)){
                $tables[]	=	$row[0];
            }
        }else{
            /* If $tables is an array then assign directly else explode the string */
            $tables	=	is_array($tables) ? $tables : explode(',',$tables);
        }
        /* Create the database */
        $sql	=	'SET FOREIGN_KEY_CHECKS = 0;'."\n".'CREATE DATABASE IF NOT EXISTS `'.$this->database."`;\n";
        /* Use the database */
        $sql	.=	'USE `'.$this->database.'`;';

        /* Loop throug all the $tables */
        foreach($tables as $table){
            /* Output message */
            //echo 'Logging Table : `'.$table.'` : ';

            /* Fetch the details of the table */
            $tableDetails	=	mysqli_query($this->link, "SELECT * FROM ".$table);

            /* Check the Number of Coloumns in the table */
            $totalCols	=	mysqli_num_fields($tableDetails);

            /* If the table exists then drop */
            $sql		.=	"\n\nDROP TABLE IF EXISTS `".$table."`;\n";
            /* Create the table structure */
            $result1	=	mysqli_fetch_row(mysqli_query($this->link,'SHOW CREATE TABLE '.$table));
            $sql		.=	$result1[1].";\n\n";


            while($row = mysqli_fetch_row($tableDetails)){
                $sql	.=	'INSERT INTO `'.$table.'` VALUES(';
                for($j=0; $j<$totalCols; $j++){
                    $row[$j]	=	preg_replace("/\n/","\\n",addslashes($row[$j]));
                    if (isset($row[$j]))
                    {
                        $sql .= '"'.$row[$j].'"' ;
                    }
                    else
                    {
                        $sql.= '""';
                    }

                    if ($j < ($totalCols-1))
                    {
                        $sql .= ', ';
                    }
                }
                $sql	.=	"); \n";
            }
            //echo 'Completed <br/>';
        }
        $sql .= 'SET FOREIGN_KEY_CHECKS = 1;';
        /* If the 2nd parameter was not specified then default one will be passed */
        $backupDirectory = ($backupDirectory == '') ? $this->backupDirectory : $backupDirectory;
        if($this->logDatabase($sql,$backupDirectory)){
        }

    }

    public function logDatabase($sql,$backupDirectory = ''){
        if(!$sql){
            return false;
        }
        $filename	=	'log_'.$this->database.'-'.date('Y-m-d_H-i-s');
        if(!file_exists($backupDirectory)){
            if(mkdir($backupDirectory,0755)){
                $this->filename = $filename;
                $fileHandler	=	fopen($backupDirectory.'/'.$filename.'.sql','w+');
                fwrite($fileHandler,$sql);
                fclose($fileHandler);
                $this->backupDirectory = $backupDirectory;
                return true;
            }
        }else{
            $this->filename = $filename;
            $fileHandler	=	fopen($backupDirectory.'/'.$filename.'.sql','w+');
            fwrite($fileHandler,$sql);
            fclose($fileHandler);
            $this->backupDirectory = $backupDirectory;
            return true;
        }
        return false;

    }

    public static function deleteDir($dirPath) {
        if (! is_dir($dirPath)) {
            throw new InvalidArgumentException("$dirPath must be a directory");
        }
        if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
            $dirPath .= '/';
        }
        $files = glob($dirPath . '*', GLOB_MARK);
        foreach ($files as $file) {
            if (is_dir($file)) {
                self::deleteDir($file);
            } else {
                unlink($file);
            }
        }
        try{
            rmdir($dirPath);
        }catch(Exception $e) {

        }
    }
}
