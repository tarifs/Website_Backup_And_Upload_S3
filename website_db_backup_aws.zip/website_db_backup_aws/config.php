<?php
// DB config
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'nuploy_web';
$db_dir = './dbBackup';

// Project config
$project_dir = '../bu1';
$project_destination = './fileBackup/';

// AWS config
$aws_region = 'us-east-1';
$aws_key = 'AKIAI7DTNPHX46KER6FA';
$aws_secret = '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';
$aws_bucket = 'carguideinfo';
?>